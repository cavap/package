def faz_acontecer():
    print("surpreendentemente surpreendente")