from setuptools import setup, find_packages
 

 
setup(
  name='impressionantementeutil',
  version='0.0.1',
  description='Faz algo impressionante. E útil',
  long_description=open('README.md').read(),
  url='',  
  author='Carlos',
  author_email='place@holder.com',
  license='MIT', 
  keywords='surpreendentemente', 
  packages=find_packages(),
  install_requires=[''] 
)